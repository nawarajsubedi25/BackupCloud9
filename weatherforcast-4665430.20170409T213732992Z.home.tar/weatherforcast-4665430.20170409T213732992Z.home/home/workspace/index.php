<?php
$forecast = "";
 $weather = "";
$error= "";
$city = "";
     if(array_key_exists("city", $_GET))
     {
         $city = str_replace(" ","",$_GET["city"]);
         $forecast = file_get_contents("http://www.weather-forecast.com/locations/".$city."/forecasts/latest");
         $file_headers = get_headers("http://www.weather-forecast.com/locations/".$city."/forecasts/latest");
        if(!$file_headers || $file_headers[0] == 'HTTP/1.1 404 Not Found') {
            $error = "The city could not be found";
        }
         else{
    

                $cutArray = explode('3 Day Weather Forecast Summary:</b><span class="read-more-small"><span class="read-more-content"> <span class="phrase">', $forecast);
                if(sizeof ($cutArray) > 1){
                    $cutAgain = explode('</span></span></span></p><div class="forecast-cont"><div class="units-cont"><a class="units metric active">', $cutArray[1]);
                    if(sizeof($cutAgain) > 1){
                        $weather = $cutAgain[0];    
                    }
                    else{
                        $error = "Some error occured. Please inform the page admin.";
                    }
                }
             else{
                 $error = "Some error occured. Please inform the page admin.";
             }
               
         }
     }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
      <title>Weather Scraper</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
  <style type="text/css">
      html { 
  background: url(bg.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
      body{
          background:none;
      }
      .container{
          text-align: center;
          margin-top:150px;
          max-width: 450px;
      }
      input{
          margin: 25px 0px;
      }
      #weather{
          margin-top:20px;
      }
      </style>
    </head>
  <body>
    <div class="container">
      <h1>What's the weather?</h1>
        <form method="get">
          <div class="form-group">
            <label for="city">Enter your city</label>
            <input type="text" class="form-control" id="city" aria-describedby="city" placeholder="Eg, Kathmandu" name="city" value=
                   "<?php 
                    if(array_key_exists("city", $_GET))
                        echo $_GET["city"]; 
                    ?>"
                   >
          </div>
  
        <button type="submit" class="btn btn-primary">Submit</button>
</form>
        <div id="weather">
            <?php
                if($weather){
                    echo '<div class="alert alert-success" role="alert">'.$weather.'</div>';
                }
            else if($error){
                echo '<div class="alert alert-danger" role="alert">'.$error.'</div>';
            }
            
            ?>
        </div>
      </div>
      
      

    <!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
  </body>
</html>
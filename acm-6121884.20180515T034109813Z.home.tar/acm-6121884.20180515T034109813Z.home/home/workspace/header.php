</<?php  ?>
<!DOCTYPE html>
<html>
<head>
<title>ACM</title>
<meta charset="UTF-8" />
<link rel="stylesheet" type="text/css" href="style/header.css" />
<!--[if IE 6]><link rel="stylesheet" type="text/css" href="styles/ie6.css" /><![endif]-->
</head>
<body>
  <div id="header">
    <div id="section">
      <br>
      <img src="/images/ulmsmall.png" style="width:100px;height:100px;"></img>
       <img src="/images/Head.png"></img>
       </div>
    <ul>
      <li class="current"><a href="index.php">Home</a></li>
      <li><a href="about.html">Events</a></li>
      <li><a href="admissions.html">Surviving CS degree</a></li>
      <li><a href="training-courses.html">Useful resources </a></li>
      <li><a href="blog.html">Contacts</a></li>
      <li><a href="membership.php">Membership</a></li>
      <li><a href="contact-us.html">FAQ</a></li>
    </ul>
    
  </div>
<html>
	<head>
		<title>Footer</title>
    <link rel="stylesheet" type="text/css" href="footer.css" />
	</head>
		<div id="footer">
    	<div>
      	<div class="section">
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="about.html">Events</a></li>
          <li><a href="admissions.html">Surviving a CS degree</a></li>
          <li><a href="training-courses.html">Useful Resources</a></li>
          <li><a href="career.html">Contacts</a></li>
          <li class="last"><a href="contact-us.html">Membership</a></li>
          <li><a href="career.html">FAQ</a></li>
        </ul>
        <p> &copy; <i>Designed by Sanjiv, Bikash, Kushal and Sandesh </i></p>
      </div>
    </div>
  </div>

</html>

<?php
?>

$( "#kane" ).click(function() {
  $( "#kane2" ).fadeToggle( "slow", "linear" );
});

$( "#gg" ).click(function() {
  $( "#ggg" ).fadeToggle( "slow", "linear" );
});


